ISLA CERO — GODOT 4 — PROTOTIPO 0.1

OBJETIVO
Primer prototipo técnico del pilar 3D: movimiento libre, cámara 360°, verticalidad, horizonte y generación procedural por semilla.

ABRIR
1. Instala Godot 4.x.
2. Importa la carpeta del proyecto o abre project.godot.
3. Pulsa F6/F5.

CONTROLES PC
WASD o flechas: mover
Ratón: cámara 360°
Espacio: saltar
Shift: correr
Esc: liberar ratón
Botón NUEVA SEMILLA: reconstruye la isla.

IMPORTANTE
- No es el arte final.
- No usa aún ninguna API de IA: primero validamos que el generador 3D sea jugable y reproducible.
- La siguiente fase prevista es añadir validación de rutas y luego un World Spec generado por API.
- El faro dorado funciona como objetivo visual de la semilla.


PATCH v0.1.1
- Corregido el error: Invalid assignment of property 'rotation' ... null instance.
- CameraPivot ahora existe antes de que se active player.gd.
- Añadida comprobación defensiva del pivot.


ISLA CERO CROSSPLAY v0.2
========================
Objetivo: una sola base jugable que se adapte automáticamente.

CONTROLES PC
- WASD / flechas: mover
- Ratón: cámara
- Espacio: saltar
- Shift: correr

MANDO
- Stick izquierdo: mover
- Botón A / equivalente: saltar
- Botón B / equivalente: correr
(La cámara derecha se ampliará en la siguiente iteración.)

SMARTPHONE / TABLET
- Joystick virtual izquierdo automático
- Arrastre en zona derecha para cámara
- Botones SALTAR y CORRER
- HUD reajustado al tamaño de pantalla

ADAPTACIÓN
- UI anclada y escalable
- Detección táctil automática
- Soporte teclado/ratón y gamepad
- Base preparada para Android, escritorio y futuros exports de consola/web

NOTA
Cross-play real online (mismos servidores/partidas entre plataformas) requerirá posteriormente
capa de cuentas, red, sincronización y backend. Esta build establece la capa cross-platform
de controles y presentación.


PATCH CROSSPLAY v0.2.1
- Joystick táctil rehecho con origen dinámico donde apoyas el pulgar.
- La capa HUD ya no intercepta los gestos de movimiento.
- Movimiento relativo a la cámara.
- Cámara táctil derecha conservada.
- Soporte de stick derecho de mando añadido.
- Salto táctil con latch para evitar repetición.
- Mantiene teclado/ratón y mando.


v0.2.2 — FASE 1 DE INPUT MÓVIL
- Eliminado temporalmente el joystick dinámico.
- Añadida cruceta táctil fija siempre visible.
- SALTAR y CORRER siempre visibles.
- Cámara táctil en la mitad derecha.
- PC/mando se mantienen, pero no son la prioridad de esta prueba.
- Objetivo: demostrar primero que el personaje se mueve de forma fiable en móvil.


HUD RESPONSIVE B
- Controles táctiles anclados al área visible real.
- Escala según el lado corto de la pantalla.
- Márgenes de seguridad amplios.
- Recalcula al cambiar tamaño/orientación.
- Se conserva el movimiento ya validado.
- Esta build NO añade nuevas capas de crossplay.
